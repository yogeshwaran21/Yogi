import { Injectable} from "@angular/core"

@Injectable()

export class User{
    userId:string="unknown";
    password:string="unknown";
    emailId:string="unknown";
}